from flask import Flask, request,render_template, url_for ,redirect

#UPLAD_FLODER ='static/uploads'

app = Flask(__name__)

@app.route('/')
def hello():
    return render_template('test.html')

@app.route('/test',methods=['GET', 'POST'])
def test():
    return render_template('test.html')

@app.route('/first1',methods=['GET','POST'])
def first1():
    return render_template('first1.html')

def display_on_console(vaccine_name,city_name,ava_date,vacc_qty,expiry_date):
    print("Vaccine Name :\t",vaccine_name)
    print("Available In :\t",city_name)
    print("Date :\t",ava_date)
    print("Vaccine Qty :\t",vacc_qty)
    print("Expiry Date :\t",expiry_date)

@app.route('/first2',methods=['GET','POST'])
def first2():
    print("Inside first2")
    _vac_name = request.form['fname']
    ava_city = request.form['dname']
    ava_date = request.form['lname']
    qt_vacc = request.form['mname']
    ex_date = request.form['ename']
    display_on_console(_vac_name,ava_city,ava_date,qt_vacc,ex_date)
    print("Calling HTML Page in app route first 2")
    return render_template('first1.html',_vac_name=_vac_name,ava_city=ava_city,ava_date=ava_date,qt_vacc=qt_vacc,ex_date=ex_date)    

@app.route('/second2',methods=['GET', 'POST'])


def second2():
    return render_template('second2.html')



@app.route('/second2',methods=['GET','POST'])
def second1():
    _vac_name = request.form['vname']
    av_city = request.form['aname']
    av_date = request.form['avname']
    qtn_vacc = request.form['nname']
    exp_date = request.form['qname']
    display_on_console(_vac_name,av_city,av_date,qtn_vacc,exp_date)
    return render_template('second2.html',_vac_name=_vac_name,av_city=av_city,av_date=av_date,qtn_vacc=qtn_vacc,exp_date=exp_date)

@app.route('/third',methods=['GET','POST'])
def third():
    # // list of list
    # // data = [[name,manu,3,4],[name,manu,3,4]]
    
    return render_template('third.html')

def third3():
    return render_template('third.html')

if __name__ == '__main__':    
    # This is used when running locally. Gunicorn is used to run the
    #app.run(host='0.0.0.0', port=8080, debug=True, processes=4, threaded=True)
    app.run(threaded=True,debug=True)
    #app.run(host='127.0.0.1', port=8080, debug=True)
## [END app]

